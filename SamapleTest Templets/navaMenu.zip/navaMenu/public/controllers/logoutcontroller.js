mainapp.controller( 'LogoutController', ['$scope', '$global', '$location', function($scope, $global, $location){
	$global.setShowlogin(false);
	$global.setShowlogout(false);
	$global.setShowhomepage(false);
	$global.setCha(false);
	$global.setBondedWareHouse(false);
	$global.setTransport(false);
	$global.setNavBar(false);
	$global.setVehicleMaintenance(false);
	$global.setMasterDataBase(false);
	$global.setAdminlogged(false);

	$location.path('/login');

}]);