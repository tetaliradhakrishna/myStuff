var mainapp = angular.module('dashboard', ['ngRoute', 'xeditable']);

mainapp.run(['$global', function ($global) {

	$global.setShowlogin(false);
	$global.setShowlogout(false);
	$global.setShowhomepage(false);
	$global.setCha(false);
	$global.setBondedWareHouse(false);
	$global.setTransport(false);
	$global.setNavBar(false);
	$global.setVehicleMaintenance(false);
	$global.setMasterDataBase(false);

}]);


mainapp.config(function ($routeProvider) {
	$routeProvider
		.when('/homepage', {
			controller: 'HomePageController',
			templateUrl: '../homepage.html'
		})
		.when('/cha', {
			controller: 'CHAController',
			templateUrl: '../cha.html'
		})
		.when('/login', {
			controller: 'LoginController',
			templateUrl: '../login.html'
		})
		.when('/logout', {
			controller: 'LogoutController',
			templateUrl: '../login.html'
		})
		.when('/adminconsole', {
			controller: 'AdminConsoleController',
			templateUrl: '../adminconsole.html'
		})

		.when('/transport', {
			controller: 'transportController',
			templateUrl: '../transport.html'
		})
		.when('/success', {
			//controller: 'AdminConsoleController',
			templateUrl: '../success.html'
		})
		.when('/error', {
			//controller: 'AdminConsoleController',
			templateUrl: '../error.html'
		})
		.when('/vehicleMaintenance', {
			controller: 'vehicleMaintenanceController',
			templateUrl: '../vehicleMaintenance.html'
		})
		.when('/bondedWareHouse', {
			controller: 'bondedWareHouseController',
			templateUrl: '../bondedWareHouse.html'
		})
		.when('/masterDataBase', {
			controller: 'masterDataBaseController',
			templateUrl: '../masterDatabase.html'
		})
		.otherwise({
			redirectTo: '/login'
		});
});

mainapp.factory('$global', function () {

	var showlogin = true;
	var showhomepage = true;
	var showlogout = true;
	var adminlogged = false;
	var cha = false;
	var	bondedWareHouse = false;
	var	transport = false;
	var	vehicleMaintenance = false;
	var	masterDataBase = false;
	var	navBar = false;




	return {
		setShowlogin: function (val) {
			showlogin = val;
		},
		setShowhomepage: function (val) {
			showhomepage = val;
		},
		setShowlogout: function (val) {
			showlogout = val;
		},
		setAdminlogged: function (val) {
			adminlogged = val;
		},
		getShowlogin: function () {
			return showlogin;
		},
		getShowhomepage: function () {
			return showhomepage;
		},
		getShowlogout: function () {
			return showlogout;
		},
		getAdminlogged: function () {
			return adminlogged;
		},
		setCha: function (val) {
			cha = val
		},
		getCha: function () {
			return cha;
		},
		setBondedWareHouse: function (val) {
			bondedWareHouse = val
		},
		getBondedWareHouse: function () {
			return bondedWareHouse;
		},
		setTransport: function (val) {
			transport = val
		},
		getTransport: function () {
			return transport;
		},
		setVehicleMaintenance: function (val) {
			vehicleMaintenance = val
		},
		getVehicleMaintenance: function () {
			return vehicleMaintenance;
		},
		setMasterDataBase: function (val) {
			masterDataBase = val
		},
		getMasterDataBase: function () {
			return masterDataBase;
		},
		setNavBar: function (val) {
			navBar = val ;
		},
		getNavBar: function () {
			return navBar;
		}
	};
});

mainapp.controller('NavController', ['$scope', '$global', function ($scope, $global) {
	$scope.template = {
		navmenu: 'navmenu.html'
	};

	 
	$scope.noneStyle = false;
	$scope.bodyCon = false;


	//Toggle the styles
	$scope.toggleStyle = function () {
		//If they are true, they will become false 
		//and false will become true
		$scope.bodyCon = !$scope.bodyCon;
		$scope.noneStyle = !$scope.noneStyle;
	}
	//add class to search box
	$scope.openSearch = false;
	$scope.searchToggle = function () {

		$scope.openSearch = !$scope.openSearch;

	}
	// navigation show and hide 
	$scope.shownavBar = $global.getNavBar();
	$scope.showlogin = $global.getShowlogin();
	$scope.showlogout = $global.getShowlogout();
	$scope.showhomepage = $global.getShowhomepage();
	$scope.showCHA = $global.getCha();
	$scope.showBondedWareHouse = $global.getBondedWareHouse();
	$scope.ShowTransport = $global.getTransport();
	$scope.showVehicleMaintenance = $global.getVehicleMaintenance();
	$scope.showMasterDataBase = $global.getMasterDataBase();

	 //console.log($scope.shownavBar);

}]);