mainapp.controller( 'transportController', ['$scope', '$global', '$location', '$filter', '$http', function($scope, $global, $location, $filter, $http){
	if(! $global.getAdminlogged())
	{
		$location.path('/login');
	}
	$global.setShowlogin(false);
	$global.setShowlogout(true);
	$global.setShowhomepage(true);
	$global.setCha(true);
	$global.setBondedWareHouse(true);
	$global.setTransport(true);
	$global.setNavBar(true);
	$global.setVehicleMaintenance(true);
	$global.setMasterDataBase(true);
	$global.setAdminlogged(true);

	
}]);