
mainapp.controller( 'LoginController', ['$scope', '$location', '$http', '$global', function($scope, $location, $http ,$global){
	
	$global.setShowlogin(false);
		$global.setShowlogout(false);
		$global.setShowhomepage(false);
		$global.setCha(false);
		$global.setBondedWareHouse(false);
		$global.setTransport(false);
		$global.setNavBar(false);
		$global.setVehicleMaintenance(false);
		$global.setMasterDataBase(false);
		$global.setAdminlogged(false);

	$scope.login = function(){
		
	
		if( $scope.userid === 'admin' && $scope.password === 'admin')
					{
						$global.setShowlogin(false);
						$global.setShowlogout(true);
						$global.setShowhomepage(true);
						$global.setCha(true);
						$global.setBondedWareHouse(true);
						$global.setTransport(true);
						$global.setNavBar(true);
						$global.setVehicleMaintenance(true);
						$global.setMasterDataBase(true);
						$global.setAdminlogged(true);
						$location.path('/homepage');
			
					}
					else{
						$scope.message = '*Please enter the correct username and password.';
					
					}
	
};

$scope.OnchangeUserNameAndPassword = function(){
	$scope.message =  "";

};

}]);
