mainapp.controller( 'AdminConsoleController', ['$scope', '$global', '$location', function($scope, $global, $location){
	if(! $global.getAdminlogged())
	{
		$location.path('/login');
	}




	$global.setShowlogin(false);
	$global.setShowlogout(true);
	$global.setShowhomepage(true);
	$global.setCha(false);
	$global.setBondedWareHouse(false);
	$global.setTransport(false);
	$global.setNavBar(true);
	$global.setVehicleMaintenance(false);
	$global.setMasterDataBase(false);
	
}]);